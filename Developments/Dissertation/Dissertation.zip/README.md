### What is this repository for? ###

This is a WIP for a template for Latex for thesis in the [CS Dept.](http://www.dcc.fc.up.pt/) of the [School of Sciences](http://www.fc.up.pt/) in [Univ. of Porto](http://www.up.pt/). This is a personal development with no official release (i.e. using this does not entail an official sanction of the format).

You should also check what is stated in [Estrutura e Layout de teses](https://sigarra.up.pt/fcup/pt/conteudos_geral.ver?pct_pag_id=1011511&pct_parametros=pv_unidade=97&pct_grupo=33673&pct_grupo=33670&pct_grupo=33675&pct_grupo=33683&pct_grupo=36711#36711)

### How do I get set up? ###

* tested using MikTex and its pdflatex

### Contribution guidelines ###

* You are free to clone this template and use it as you see fit.